@echo off
start OpenFK.exe
start FunkeySelectorGUI.exe
