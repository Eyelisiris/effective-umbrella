
1. Make sure you are using funkeys 5.0 (paradox green)
2. Close U.B. Funkeys
3. Go into your RadicaGames folder (C:/Program Files/U.B. Funkeys/RadicaGames/)
4. Rename Main.swf to Main_good.swf
5. Download This file (done)
6. Extract the file you just downloaded in the same folder as Main_good.swf
7. Launch U.B. funkeys and log in -- DO NOT DO ANYTHING ONCE YOU HAVE LOADED INTO FUNKEYS TOWN
8. Close U.B. Funkeys
9. Rename Main.swf to Main_TRUNK_HACK.swf
10. Rename Main_good.swf to Main.swf