import { xml2js, js2xml, Element } from "xml-js";
import { readFile, writeFile } from "fs/promises";

const profileName = process.argv[2];
const amountToGive = Number(process.argv[3]) || 1;

const oldProfileXML = await readFile(`./RadicaGame/data/${profileName}/profile.xml`, { encoding: "utf-8" });
const parsedProfile = xml2js(oldProfileXML) as Element;
const items = parsedProfile.elements![0].elements![2].elements![0].elements! as {
    type: "element";
    name: "item";
    attributes: {
        used: string | number;
        total: string | number;
        id: string;
    }
}[];

const trunkXML = await readFile("./RadicaGame/data/system/trunk.xml", { encoding: "utf-8" });
const parsedTrunk = xml2js(trunkXML) as Element;

interface TrunkItemElement {
    type: "element";
    name: "item";
    attributes: {
        name: string;
        id: string;
    };
    elements?: [
        {
            type: "element";
            name: "info";
            elements: {
                type: "text";
                text: string;
            }[];
        }
    ];
}

// Function to extract items from a specific section
const extractItems = (sectionName: string) => {
    const section = parsedTrunk.elements![0].elements?.find(e => e.name === sectionName);
    return section?.elements?.filter(e => e.type === "element" && e.name === "item") as TrunkItemElement[] ?? [];
};

// Get all items from both <trunk> and <cleanings>
const trunkItems = extractItems("items");
const cleaningItems = extractItems("cleanings");

// Ensure Elefunk is included
const elefunkID = "70021a";
if (!cleaningItems.some(item => item.attributes.id === elefunkID)) {
    cleaningItems.push({
        type: "element",
        name: "item",
        attributes: {
            name: "Elefunk",
            id: elefunkID,
        },
    });
}

const allItems = [...trunkItems, ...cleaningItems];
const allItemIDs = allItems.map(item => item.attributes.id);

// Add items to profile.xml
for (const itemID of allItemIDs) {
    const existingItem = items.find(item => item.attributes.id === itemID);
    if (existingItem) {
        existingItem.attributes.total = Number(existingItem.attributes.total) + amountToGive;
        continue;
    }
    items.push({
        type: "element",
        name: "item",
        attributes: {
            used: 0,
            total: amountToGive,
            id: itemID,
        }
    });
}

// Ensure Elefunk is added directly if missing
if (!items.some(item => item.attributes.id === elefunkID)) {
    items.push({
        type: "element",
        name: "item",
        attributes: {
            used: 0,
            total: amountToGive,
            id: elefunkID,
        }
    });
}

// Save the modified profile.xml
const newProfileXML = js2xml(parsedProfile, { spaces: 2 }).replace(/(\S)\/>$/gm, "$1 />");
await writeFile(`./RadicaGame/data/${profileName}/profile.xml`, newProfileXML);

console.log(`✅ Successfully added ${amountToGive} of each item to ${profileName}'s profile.xml!`);
